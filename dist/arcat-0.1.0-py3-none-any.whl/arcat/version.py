"""
Version file for arcat package.

Version follows Semantic Versioning:
MAJOR.MINOR.PATCH
"""

__version__ = "0.1.0"
